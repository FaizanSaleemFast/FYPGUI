package TestCase;

import java.util.ArrayList;

public class TestCaseGroup {

	
	public ArrayList<TestCase> testCases = new ArrayList<TestCase>();

	public ArrayList<TestCase> getTestCases() {
		return testCases;
	}

	public void setTestCases(ArrayList<TestCase> testCases) {
		this.testCases = testCases;
	}
	
}


