package TestCase;

import java.util.ArrayList;

public class TestCase {

	public ArrayList<TestCaseFragment> testCaseFragments = new ArrayList<>();

	public ArrayList<TestCaseFragment> getTestCaseFragments() {
		return testCaseFragments;
	}

	public void setTestCaseFragments(ArrayList<TestCaseFragment> testCaseFragments) {
		this.testCaseFragments = testCaseFragments;
	}		
	
}
